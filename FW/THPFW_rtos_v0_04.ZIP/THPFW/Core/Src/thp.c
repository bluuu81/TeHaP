/*
 * thp.c
 *
 *  Created on: May 9, 2023
 *      Author: bluuu & Mis
 */

#include "main.h"
#include "thp.h"
#include "bq25798.h"
#include "cmsis_os.h"
#include "sim80xDrv.h"

#define GSM_RESTART_INTERVAL 30*3600*24   // 30ms tick x secperhour x 24h (set to 0 for disable)

volatile uint8_t charger_state;

TMP117_struct_t TMP117;
SHT3_struct_t SHT3;
MS8607_struct_t MS8607;
BME280_struct_t BME280;
DPS368_struct_t DPS368;

BMP280_HandleTypedef bmp280;

Config_TypeDef config;
volatile uint16_t new_tim_interval; //w sekundach
volatile uint16_t tim_interval = 0;
volatile uint8_t disp_type;
volatile uint32_t seconds;
uint16_t meas_count = 10;
uint8_t meas_cont_mode = 1;
uint8_t sensors_data_ready;

uint16_t tmp117_avr;
volatile uint8_t dps368_ovr_temp;
volatile uint8_t dps368_ovr_press;
volatile uint16_t dps368_ovr_conf;
uint8_t sht3_mode;

volatile uint32_t offTim;
volatile uint32_t gps_start = 0, gps_interval = 30;			// puerwszy odczyt GPS po 30s od zalaczenia
osThreadId measTaskHandle, gpsTaskHandle, GprsSendTaskHandle;
bool gpsTaskFlag, GprsSendTaskFlag;

uint32_t meas_start;
uint8_t gprs_send_status, simOn_lock;

enum {
	GPRSsendStatusIdle,
	GPRSsendStatusInprogress,
	GPRSsendStatusOk,
	GPRSsendStatusError
};

void _close(void) {}
void _lseek(void) {}
void _read(void)  {}
void _kill(void)  {}
void _isatty(void) {}
void _getpid(void) {}
void _fstat(void) {}

//volatile uint32_t tim_secdiv, tim_meas;

void ReinitTimer(uint16_t interval)
{
	meas_start = seconds;
}

void HAL_SYSTICK_Callback(void)
{
}


void check_powerOn()
{
	uint32_t timon = HAL_GetTick();
	  while(Power_SW_READ() == GPIO_PIN_SET)
	  {
//		  printf("2. Check Power BUT\r\n");
	    if(HAL_GetTick() - timon > 1000) {    // 1 sec pushing
	    	timon = HAL_GetTick();
	        POWER_ON();    // pull-up power supply
	    	printf("Power ON\r\n");
	        break;                // break while loop
	    }
	  }
}

void check_powerOff()
{
  static uint8_t keystate;
  if(Power_SW_READ()) { //power button pressed
	 LED2_ON();
	 keystate = 1;
     if(offTim && HAL_GetTick() - offTim > 2000) {    // 2 sec pressed
    	 printf("Power off\r\n");
    	 LED2_OFF();
    	 LED1_OFF();
		 Sim80x_SetPower(0);
    	 POWER_OFF();
    	 osDelay(2000);
    	 HAL_NVIC_SystemReset();
     }
  } else {
	  offTim = HAL_GetTick();   // button released, update offTim
	  if(keystate) LED2_OFF();
	  keystate = 0;
  }
}

void MCUgoSleep()
{
    // prepare wakeup pin
    HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN2);
    __HAL_PWR_CLEAR_FLAG(PWR_FLAG_WU);
    HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN2);
    // go sleep
    printf("Sleep\r\n");
    POWER_OFF();
    HAL_PWR_EnterSTANDBYMode();
}

uint8_t HALcalculateCRC(uint8_t* data, uint8_t len)
{
    HAL_CRC_Init(&hcrc);
    __HAL_CRC_DR_RESET(&hcrc);
    uint32_t crc = HAL_CRC_Calculate(&hcrc, (uint32_t*)data, len);
    return (uint8_t)(crc & 0xFF);
}
/*
uint8_t calculateCRC(uint8_t data[], uint8_t len)
{
    uint8_t crc = 0xFF;
    for (uint8_t i = 0; i < len; i++)
    {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8; bit++)
        {
            if (crc & 0x80)
                crc = (crc << 1) ^ 0x31;
            else
                crc = crc << 1;
        }
    }
    return crc;
}
*/

void printCSVheader()
{
	printf("\r\n");
	printf("CNT;");
	if(TMP117.present && TMP117.sensor_use && TMP117.temp.use_meas) printf("TEMP_TMP117;");
	if(BME280.present && BME280.sensor_use && BME280.temp.use_meas) printf("TEMP_BME280;");
	if(SHT3.present && SHT3.sensor_use && SHT3.temp.use_meas) printf("TEMP_SHTC3;");
	if(MS8607.present && MS8607.sensor_use && MS8607.temp.use_meas) printf("TEMP_MS8607;");
	if(DPS368.present && DPS368.sensor_use && DPS368.temp.use_meas) printf("TEMP_DPS368;");

	if(BME280.present && BME280.sensor_use && BME280.press.use_meas) printf("PRESS_BME280;");
	if(MS8607.present && MS8607.sensor_use && MS8607.press.use_meas) printf("PRESS_MS8607;");
	if(DPS368.present && DPS368.sensor_use && DPS368.press.use_meas) printf("PRESS_DPS368;");

	if(BME280.present && BME280.sensor_use && BME280.hum.use_meas) printf("HUM_BME280;");
	if(SHT3.present && SHT3.sensor_use && SHT3.hum.use_meas) printf("HUM_SHTC3;");
	if(MS8607.present && MS8607.sensor_use && MS8607.hum.use_meas) printf("HUM_MS8607;");
	printf("\r\n");

}

void display_values (uint8_t format)
{
	switch (format)
	{
	case 1:
		printf("-----------------------\r\n");
		printf("Temperature:\r\n");
		if(TMP117.present && TMP117.sensor_use && TMP117.temp.use_meas) printf("TMP117: %.2f   ", TMP117.temp.value+TMP117.temp.offset);
		if(BME280.present && BME280.sensor_use && BME280.temp.use_meas) printf("BME280: %.2f   ", BME280.temp.value+BME280.temp.offset);
		if(SHT3.present && SHT3.sensor_use && SHT3.temp.use_meas) printf("SHTC3: %.2f   ", SHT3.temp.value+SHT3.temp.offset);
		if(MS8607.present && MS8607.sensor_use && MS8607.temp.use_meas) printf("MS8607: %.2f   ", MS8607.temp.value+MS8607.temp.offset);
		if(DPS368.present && DPS368.sensor_use && DPS368.temp.use_meas) printf("DPS368: %.2f   ", DPS368.temp.value+DPS368.temp.offset);
		printf("\r\n-----------------------\r\n");
		printf("Press:\r\n");
		if(BME280.present && BME280.sensor_use && BME280.press.use_meas) printf("BME280: %.2f   ", BME280.press.value+BME280.press.offset);
		if(MS8607.present && MS8607.sensor_use && MS8607.press.use_meas) printf("MS8607: %.2f   ", MS8607.press.value+MS8607.press.offset);
		if(DPS368.present && DPS368.sensor_use && DPS368.press.use_meas) printf("DPS368: %.2f   ", DPS368.press.value+DPS368.press.offset);
		printf("\r\n-----------------------\r\n");
		printf("Hum:\r\n");
		if(BME280.present && BME280.sensor_use && BME280.hum.use_meas) printf("BME280: %.2f   ", BME280.hum.value+BME280.hum.offset);
		if(SHT3.present && SHT3.sensor_use && SHT3.hum.use_meas) printf("SHTC3: %.2f   ", SHT3.hum.value+SHT3.hum.offset);
		if(MS8607.present && MS8607.sensor_use && MS8607.hum.use_meas) printf("MS8607: %.2f   ", MS8607.hum.value+MS8607.hum.offset);
		printf("\r\n-----------------------\r\n");
		break;

	case 2:
		printf("%u;",++csvcnt);
		if(TMP117.present && TMP117.sensor_use && TMP117.temp.use_meas) printf("%.2f;",TMP117.temp.value+TMP117.temp.offset);
		if(BME280.present && BME280.sensor_use && BME280.temp.use_meas) printf("%.2f;",BME280.temp.value+BME280.temp.offset);
		if(SHT3.present && SHT3.sensor_use && SHT3.temp.use_meas) printf("%.2f;",SHT3.temp.value+SHT3.temp.offset);
		if(MS8607.present && MS8607.sensor_use && MS8607.temp.use_meas) printf("%.2f;",MS8607.temp.value+MS8607.temp.offset);
		if(DPS368.present && DPS368.sensor_use && DPS368.temp.use_meas) printf("%.2f;",DPS368.temp.value+DPS368.temp.offset);

		if(BME280.present && BME280.sensor_use && BME280.press.use_meas) printf("%.2f;",BME280.press.value+BME280.press.offset);
		if(MS8607.present && MS8607.sensor_use && MS8607.press.use_meas) printf("%.2f;",MS8607.press.value+MS8607.press.offset);
		if(DPS368.present && DPS368.sensor_use && DPS368.press.use_meas) printf("%.2f;",DPS368.press.value+DPS368.press.offset);

		if(BME280.present && BME280.sensor_use && BME280.hum.use_meas) printf("%.2f;",BME280.hum.value+BME280.hum.offset);
		if(SHT3.present && SHT3.sensor_use && SHT3.hum.use_meas) printf("%.2f;",SHT3.hum.value+SHT3.hum.offset);
		if(MS8607.present && MS8607.sensor_use && MS8607.hum.use_meas) printf("%.2f;",MS8607.hum.value+MS8607.hum.offset);
		printf("\r\n");
		break;

	default:
		break;
	}

}

void getConfVars()
{
	  TMP117.sensor_use = config.TMP117_use;
	  SHT3.sensor_use = config.SHT3_use;
	  MS8607.sensor_use = config.MS8607_use;
	  BME280.sensor_use = config.BME280_use;
	  DPS368.sensor_use = config.DPS368_use;

	  TMP117.sensor_conf = config.TMP117_conf;
	  TMP117.temp.use_meas = config.TMP117_t_use;
	  TMP117.temp.offset = config.TMP117_t_offset;

	  BME280.sensor_conf = config.BME280_conf;
	  BME280.temp.use_meas = config.BME280_t_use;
	  BME280.temp.offset = config.BME280_t_offset;

	  SHT3.sensor_conf = config.SHT3_conf;
	  SHT3.temp.use_meas = config.SHT3_t_use;
	  SHT3.temp.offset = config.SHT3_t_offset;

	  MS8607.sensor_conf = config.MS8607_conf;
	  MS8607.temp.use_meas = config.MS8607_t_use;
	  MS8607.temp.offset = config.MS8607_t_offset;

	  DPS368.sensor_conf = config.DPS368_conf;
	  DPS368.temp.use_meas = config.DPS368_t_use;
	  DPS368.temp.offset = config.DPS368_t_offset;

	  BME280.press.use_meas = config.BME280_p_use;
	  BME280.press.offset = config.BME280_p_offset;
	  MS8607.press.use_meas = config.MS8607_p_use;
	  MS8607.press.offset = config.MS8607_p_offset;
	  DPS368.press.use_meas = config.DPS368_p_use;
	  DPS368.press.offset = config.DPS368_p_offset;

	  BME280.hum.use_meas = config.BME280_h_use;
	  BME280.hum.offset = config.BME280_h_offset;
	  SHT3.hum.use_meas = config.SHT3_h_use;
	  SHT3.hum.offset = config.SHT3_h_offset;
	  MS8607.hum.use_meas = config.MS8607_h_use;
	  MS8607.hum.offset = config.MS8607_h_offset;
}

// ******************************************************************************************************

void SendTestMessage()
{
	char tekst[100];
	Sim80x_GetTime();		// pobranie czasu z RTC sim868
	sprintf(tekst, "Test Wysylania przez GPRS z tasku GprsSend, Czas: %02u:%02u:%02u\r\n",
			Sim80x.Gsm.Time.Hour, Sim80x.Gsm.Time.Min, Sim80x.Gsm.Time.Sec);

	Sim80x.GPRS.SendStatus = GPRSSendData_Idle;
	for(int i=0; i<5; ++i) {
		//GPRS_SendString(tekst);
		GPRS_SendRaw((uint8_t*)tekst, strlen(tekst));
		uint8_t tout = 0;
		while(Sim80x.GPRS.SendStatus != GPRSSendData_SendOK) {
			osDelay(100);
			if(++tout >= 50) break;			// break while - tout
		}
		if(tout < 50) {printf("Sending OK !\r\n"); break;}	// break for
	}

	if(Sim80x.GPRS.SendStatus != GPRSSendData_SendOK) {
		printf("GPRS Sending Failed !\r\n");
		gprs_send_status = GPRSsendStatusError;			// ustaw globalny status wysylania na error
	}
	osDelay(5000);			// normalnie zbedny, ale to dla mozliwosci odebrania danych z serwera.
							// zamiast tego powinno byc oczekiwanie na potwierdzenie z serwera (jesli wystepuje)
}


void GprsSendTask(void const *argument)
{
	gprs_send_status = GPRSsendStatusInprogress;					// ustaw globalny status wysylania na "in progress"
	if(Sim80x.GPRS.Connection < GPRSConnection_GPRSup ||
	   Sim80x.GPRS.Connection > GPRSConnection_ConnectOK)	{		// nie polaczony do GPRS
		bool status = GPRS_ConnectToNetwork("INTERNET", "", "", false);
		printf("Connect to network: %s\r\n", status ? "OK":"ERROR");
		printf("Connected to GPRS, IP: %s\r\n", Sim80x.GPRS.LocalIP);
		osDelay(250);
		if(!status) goto error;
	} else printf("GPRS is UP\r\n");
	printf("Connecting to server: %s\r\n", GPRS_ConnectToServer("85.222.37.192", 10011) ? "OK":"ERROR");  // IP & port
	uint8_t tout = 0;
	while(Sim80x.GPRS.Connection != GPRSConnection_ConnectOK)	{	// gotowy do wysylania danych ?
		osDelay(100);
		if(++tout >= 100) break;			// timeout na 10 sekund
	}
	if(tout < 100) {						// nie bylo timeout

		SendTestMessage();					// serwer połączony, pogadaj z nim
	}

	GPRS_DisconnectFromServer();			// rozlacz od serwera
	osDelay(300);
	GPRS_DeactivatePDPContext();			// wylacz GPRS
	osDelay(50);
error:
	GprsSendTaskFlag = 0;					// odblokuj mozliwosc ponownego uruchomienia tego taska
	vTaskDelete(NULL);						// usun task z pamieci jako juz zbedny
}


bool StartSendGPRS(void)
{
	if(GprsSendTaskFlag == 0 && Sim80x.Status.RegisterdToNetwork) {
		osThreadDef(SendGPRSTask, GprsSendTask, osPriorityNormal, 0, 256);
		GprsSendTaskHandle = osThreadCreate(osThread(SendGPRSTask), NULL);
		GprsSendTaskFlag = 1;
		return true;			// poprawnie uruchomiono task
	}
	return false;				// nie uruchomiono tasku bo juz działa
}

void  GPRS_UserNewData(char *NewData, uint16_t len)		// callback dla danych przyjetych z serwera
{
	_write(0, NewData, len);
	printf("\r\n");
}

// *******************************************************************************************
// SIM868 watchdog & autorestart

void GsmWdt(void)
{
	static uint8_t  gsm_led_state;
	static uint16_t gsm_wdt;
#if(GSM_RESTART_INTERVAL > 0)
	static uint32_t gsm_restart_time = GSM_RESTART_INTERVAL;
#endif
	// watchdog dla GSM
	gsm_wdt++;
	if(!gsm_led_state && SIM_WDT_READ()) {
		gsm_led_state = 1;
		gsm_wdt = 0;
	}
	if(gsm_led_state && !SIM_WDT_READ()) gsm_led_state = 0;

	if(Sim80x.Status.Power && gsm_wdt > 300) {		// 10 sekund WDT timeout
		printf("GSM module recovery!\r\n");
		Sim80x.Status.FatalError = 1;
	} else if(!Sim80x.Status.Power) gsm_wdt = 0;

#if(GSM_RESTART_INTERVAL > 0)
    if(gsm_restart_time) gsm_restart_time--;
    if(gsm_restart_time == 0) {						// cykliczny restart SIM868 co 24h
        uint8_t msg_in_process = 0;
        for(uint8_t i=0 ;i<sizeof(Sim80x.Gsm.HaveNewMsg); ++i) {
            if(Sim80x.Gsm.HaveNewMsg[i] > 0) msg_in_process = 1;
        }

        if(!Sim80x.GPS.RunStatus &&                                 // GPS OFF
           Sim80x.GPRS.Connection == GPRSConnection_Idle &&         // Nie ma komunikacji GPRS
           !Sim80x.Status.Busy &&                                   // Nie jest obslugiwana komenda AT
           Sim80x.Gsm.GsmVoiceStatus == GsmVoiceStatus_Idle &&      // Nie trwa polaczenie voice
           Sim80x.Gsm.MsgUsed == 0 &&                               // nie ma w pamieci nieobsluzonych SMS
           msg_in_process == 0) {                                   // nie jest obslugiwany przychodzacy SMS
            gsm_restart_time = GSM_RESTART_INTERVAL;
            Sim80x.Status.FatalError = 1;                           // wymus pelny restart SIM800
            printf("Sheduled GSM restart.\r\n");
        } else gsm_restart_time = 10*5;                             // nie wolno restartowac, kolejny test za 5s.
    }
#endif

	if(Sim80x.Status.FatalError) {			// odpal restart GSM
		printf("Restarting...\r\n");
		HAL_GPIO_WritePin(_SIM80X_POWER_KEY_GPIO,_SIM80X_POWER_KEY_PIN,GPIO_PIN_SET);
		osDelay(1200);
		printf("RST 2\r\n");
		HAL_GPIO_WritePin(_SIM80X_POWER_KEY_GPIO,_SIM80X_POWER_KEY_PIN,GPIO_PIN_RESET);
		osDelay(4000);
		printf("GSM power UP.\r\n");
		memset(&Sim80x,0,sizeof(Sim80x));
		Sim80x_SetPower(true);
		osDelay(100);
		gps_start = seconds;
		gps_interval = 30;					// odczyt GPS po 30s od restartu
		GprsSendTaskFlag = 0;
		gpsTaskFlag = 0;
        gsm_wdt = 0;
	}
}

// ******************************************************************************************************

Sim80x_Time_t fixTZ(Sim80x_Time_t tim, int zone)		// adjust time with time zone. Use GSM format, zone = 15min
{
	#define LEAP_YEAR(Y)  ( !(Y%4) && ( (Y%100) || !(Y%400) ) )
	static const uint8_t monthDays[]={31,28,31,30,31,30,31,31,30,31,30,31};
	uint8_t monthLength;
	for(int i=0; i<abs(zone); ++i) {
		int Min = (int)tim.Min + (15*zone);
		if(zone > 0 && Min > 59) {
			Min -= 60;
			if(++tim.Hour > 23)	{
				tim.Hour = 0;
				if (tim.Month==2) { 		// luty
				  if (LEAP_YEAR(tim.Year)) { monthLength=29; } else { monthLength=28; }		// luty ma 28 czy 29 ?
				} else { monthLength = monthDays[tim.Month-1]; }							// inny miesiac
				if(++tim.Day > monthLength) {												// zmiana miesiaca ?
					tim.Day = 1;
					if(++tim.Month > 12) {tim.Month = 1; tim.Year++;}
				}
			}
		} else if(zone < 0 && Min < 0) {
			Min += 60;
			int Hour = tim.Hour;			// konwersja na int ze znakiem aby wykryć ujemne wartosci godzin
			if(--Hour < 0) {
				Hour = 23;
				if(--tim.Day < 1) {
					if(--tim.Month < 1)  {tim.Month = 12; tim.Year--;}							// oblucz nowy miesiac i rok
					if (tim.Month==2) { 														// jak wyszedl luty
						if (LEAP_YEAR(tim.Year)) { monthLength=29; } else { monthLength=28; }	// luty ma 28 czy 29 ?
					} else { monthLength = monthDays[tim.Month-1]; }							// inny miesiac
					tim.Day = monthLength;								// ustaw na ostatni dzien miesiaca
				}
			}
			tim.Hour = Hour;
		}
		tim.Min = Min;
	}
	tim.Zone += zone;
	return tim;
}

void GpsReadTask(void const *argument)
{
	uint8_t time_updated = 0;
	printf("GPS start.\r\n");
	GPS_SetPower(1);
	uint16_t GPS_tout = 0;
	while(1) {
		osDelay(1000);
		if(Sim80x.GPS.Time.Year > 2020 && !time_updated && Sim80x.GPS.Fix) {		// prawidlowy czas
			if(Sim80x.Gsm.Time.Zone == 0) Sim80x.Gsm.Time.Zone = 8;					// oszustwo ze strefą czasową
			Sim80x.Gsm.Time = fixTZ(Sim80x.GPS.Time, Sim80x.Gsm.Time.Zone);
			time_updated = Sim80x_SetTime();
			printf("GSM Time update %s.\r\n", time_updated ? "OK":"ERROR");
			printf("Current time is: %04u-%02u-%02u %02u:%02u:%02u, TZ:%d\r\n",
					Sim80x.Gsm.Time.Year, Sim80x.Gsm.Time.Month, Sim80x.Gsm.Time.Day,
					Sim80x.Gsm.Time.Hour, Sim80x.Gsm.Time.Min, Sim80x.Gsm.Time.Sec, Sim80x.Gsm.Time.Zone);
		}
		if(time_updated && Sim80x.GPS.Fix && Sim80x.GPS.SatInUse > 3) break;
		if(++GPS_tout > 180 || Sim80x.GPS.RunStatus == 0) {		// 3 minuty timeout
			printf("GPS signal not available.");
			goto gpstaskend;
		}
	}
	Sim80x_SendAtCommand("AT+CGNSCMD=0,\"$PMTK285,1,10*0D\"\r\n", 500, 1,"\r\nOK\r\n");		// 10ms BLUE blink
	printf("FIX ok, position readed.\r\n");
	osDelay(15000);			// jeszcze przez 15 sekund czytaj GPS
gpstaskend:
	GPS_SetPower(0);
	printf("GPS stopped.\r\n");
	osDelay(100);
	gpsTaskFlag = 0;
	vTaskDelete(NULL);		// usun task z pamieci jako juz zbedny
}

bool StartReadGps(void)
{
	if(gpsTaskFlag == 0) {
		osThreadDef(GPSTask, GpsReadTask, osPriorityNormal, 0, 256);
		gpsTaskHandle = osThreadCreate(osThread(GPSTask), NULL);
		gpsTaskFlag = 1;
		return true;			// poprawnie uruchomiono task
	}
	return false;				// nie uruchomiono tasku bo juz działa
}

// ******************************************************************************************************

void SensorsTask(void const *argument)
{
	uint8_t shtc3_values[6];

	printf("Sensors task created\r\n\r\n\r\n");
	while(1)
	{
		vTaskSuspend(NULL);		// zatrzymaj taki i czekaj na komende start
		LED2_ON();				// mrugniecie czerwona
		uint32_t meas_time = 0;
		uint8_t dps368_press = 0;

		// uruchomienie pomiaru w poszczegolnych czujnikach
		if(TMP117.present){
		  if(TMP117.sensor_use && TMP117.temp.use_meas) {
			  TMP117_start_meas(tmp117_avr);
			  if(meas_time < 200) meas_time = 200;
		  }
		}
		if(BME280.present){
		  if(BME280.sensor_use && (BME280.temp.use_meas || BME280.press.use_meas || BME280.hum.use_meas) ) {
			  BME280_start_meas();
			  if(meas_time < 500) meas_time = 500;
		  }
		}
		if(SHT3.present){
		  if(SHT3.sensor_use && (SHT3.temp.use_meas || SHT3.hum.use_meas)) {
			  SHTC3_start_meas(sht3_mode);
			  if(meas_time < 100) meas_time = 100;
		  }
		}
		if(DPS368.present){
		  if(DPS368.sensor_use && (DPS368.temp.use_meas || DPS368.press.use_meas)) {
			  DPS368_start_meas_temp(dps368_ovr_temp);
			  uint32_t dpstim = calcBusyTime(dps368_ovr_temp);
			  if(meas_time < dpstim) meas_time = dpstim;
			  if(DPS368.press.use_meas) dps368_press = 1;				// z DPS bedzie tez cisnienie
		  }
		}
		if(disp_type == 1) {
		  printf("Komenda startu pomiarow wyslana\r\n");
		  printf("Meas interval: %u\r\n", tim_interval);
		}

		LED2_OFF();						// mrugniecie czerwona
		osDelay(meas_time);				// odczekaj czas potrzebny na przetworzenie (maksymalny wymagany)

		// odczyt danych z czujników
		if(TMP117.present && TMP117.sensor_use){
		  if(TMP117.temp.use_meas) {
			  TMP117.temp.value = TMP117_get_temp();
		//    			  printf("Temperatura TMP117: %.2f\r\n", TMP117.temp.value);
		  }
		}
		if(BME280.present && BME280.sensor_use){
		  if(BME280.temp.use_meas) {
			  BME280.temp.value = BME280_get_temp();
		//    			  printf("Temperatura BME280: %.2f\r\n", BME280.temp.value);
		  }
		  if(BME280.press.use_meas) {
			  BME280.press.value = BME280_get_press();
		//    			  printf("Cisnienie BME280: %.2f\r\n", BME280.press.value);
		  }
		  if(BME280.hum.use_meas) {
			  BME280.hum.value = BME280_get_hum();
		//    		      printf("Wilgotnosc BME280: %.2f\r\n", BME280.hum.value);
		  }
		}
		if(SHT3.present && SHT3.sensor_use){
		  SHTC3_read_values(shtc3_values);
		  if(SHT3.temp.use_meas) {
			  SHT3.temp.value = SHTC3_get_temp(shtc3_values);
		//    			  printf("Temperatura SHT3: %.2f\r\n", SHT3.temp.value);
		  }
		  if(SHT3.hum.use_meas) {
			  SHT3.hum.value = SHTC3_get_hum(shtc3_values);
		//    			  printf("Wilgotnosc SHT3: %.2f\r\n", SHT3.hum.value);
		  }
		}
		if(MS8607.present && MS8607.sensor_use){
		  if(MS8607.temp.use_meas) {
			  MS8607.temp.value = MS8607_get_temp();
		//    			  printf("Temperatura MS8607: %.2f\r\n", MS8607.temp.value);
		  }
		  if(MS8607.press.use_meas) {
			  MS8607.press.value = MS8607_get_press();
		//    			  printf("Cisnienie MS8607: %.2f\r\n", MS8607.press.value);
		  }
		  if(MS8607.hum.use_meas) {
			  MS8607.hum.value = MS8607_get_hum();
		//    			  printf("Wilgotnosc MS8607: %.2f\r\n", MS8607.hum.value);
		  }
		}
		if(DPS368.present && DPS368.sensor_use){
		  float dps_scaled_temp = DPS368_get_scaled_temp();				// odczytaj temperature
		  if(DPS368.temp.use_meas) {
			  DPS368.temp.value = DPS368_calc_temp(dps_scaled_temp);
		//    			  printf("Temperatura DPS368: %.2f\r\n", DPS368.temp.value);
		  }
		  if(dps368_press) {											// jak ma byc cisnienie z DPS
			  DPS368_start_meas_press(dps368_ovr_press);				// uruchom przetworzenie cisnienia
			  osDelay( calcBusyTime(dps368_ovr_press) + 10);			// zaczekaj na koniec przetwarzania
   			  DPS368.press.value = DPS368_get_press(dps_scaled_temp);	// pobierz cisnienie uzywając temperatury
//    		  printf("Cisnienie DPS368: %.2f\r\n", DPS368.press.value);
		  }
		}
		sensors_data_ready = 1;
	}		// while(1)
}

// ******************************************************************************************************

void THP_MainTask(void const *argument)
{
	  POWER_OFF();
	  if(!Power_SW_READ()) HAL_NVIC_SystemReset();		// nie nacisniety power -> reset CPU
	  HAL_UART_RxCpltCallback(&huart1); //CLI
	  HAL_UART_RxCpltCallback(&huart2); //SIM
	  check_powerOn();
	  if(!Power_SW_READ()) HAL_NVIC_SystemReset();		// nie nacisniety power -> reset CPU
	  printf("\r\n\r\n\r\nInitializing (RTOS version)...\r\n");
	  if (Load_config()==0) {printf("Config loaded OK \r\n");};
	  charger_state = BQ25798_check();
	  if (charger_state) {
		  printf("Configure charger \r\n");
		  QON_EN();
		  BQ25798_Sys_Min_Voltage_write(3); 	// 3250mV
		  BQ25798_Chr_Volt_Limit_write(4200); 	// 4200mV
		  BQ25798_Chr_Curr_Limit_write(2000); 	// 2000mA
		  BQ25798_Chr_Input_Voltage_Limit_write(130); //*100mV
		  BQ25798_Chr_Input_Curr_Limit_write(200); //*10mA
		  BQ25798_Chrg_CTRL1_write(0x95);
		  BQ25798_Chrg_NTC_CTRL1_write(1);
		  CE_EN();
		  BQ25798_MPPT_CTRL(1); //MPPT ON

	  }
	  LED1_ON();
	  LED2_OFF();
	  ADC_DMA_Start();

	  TMP117.present = TMP117_check();
	  SHT3.present = SHTC3_check();
	  MS8607.present = MS8607_check();
	  BME280.present = BME280_check();
	  DPS368.present = DPS368_check();

	  getConfVars();

	  tmp117_avr=tmp117_avr_conf(TMP117.sensor_conf);
	//  printf("TMP117 conf var %x\r\n", tmp117_avr);
	  dps368_ovr_conf=dps368_ovr_config(DPS368.sensor_conf);
	  printf("DPS368 conf var %x\r\n", dps368_ovr_conf);
	  dps368_ovr_temp = (uint8_t)(dps368_ovr_conf >> 8);
	  dps368_ovr_press = (uint8_t)dps368_ovr_conf;

	  DPS368_init(FIFO_DIS, INT_NONE);
	  DPS368_temp_correct(dps368_ovr_temp);

	  sht3_mode=SHT3.sensor_conf;
	  if(sht3_mode==normal) printf("SHTC3 normal mode\r\n");
	  else printf("SHTC3 low power mode\r\n");

	  bme280_conf_change(BME280.sensor_conf);

	  MS8607_osr(MS8607.sensor_conf);
	  printf("MS8607 OSR %d\r\n", 256<<MS8607.sensor_conf);

	  disp_type = config.disp_type;
	  new_tim_interval = config.tim_interval; //w sekundach
	  if(!TMP117.present && !SHT3.present && !MS8607.present && !BME280.present && !DPS368.present)
		  disp_type = 0;

	  Sim80x_Init(osPriorityNormal);
	  printf("SIM868 module startup %s.\r\n", Sim80x.Status.Power ? "OK" : "FAILED");
	  // uruchomienie taska sensorów
	  osThreadDef(SensorTask, SensorsTask, osPriorityNormal, 0, 512);
	  measTaskHandle = osThreadCreate(osThread(SensorTask), NULL);
	  osDelay(10);

	  uint32_t ticks30ms = HAL_GetTick();
	  uint32_t ticksbqwd = HAL_GetTick();
	  uint32_t secdiv = HAL_GetTick();
	  uint8_t firstrun = 1, registered=0;

	  while (1)
	  {
		  if (new_tim_interval != tim_interval) {
			  tim_interval = new_tim_interval;
			  config.tim_interval = tim_interval;
		  }

		  CLI();

		  // miganie LED i test wyłącznika
		  if(HAL_GetTick()-ticks30ms >= 30) {
			  ticks30ms = HAL_GetTick();
			  LED1_TOGGLE();
			  check_powerOff();
			  GsmWdt();

			  if(!registered && Sim80x.Status.RegisterdToNetwork) {
				  printf("Succesfully registered to network.\r\n");
				  registered = 1;
			  }
			  if(registered && Sim80x.Status.RegisterdToNetwork == 0) registered = 0;
		  }

		  // reset BQ
		  if(HAL_GetTick()-ticksbqwd >= 15000) {
			  ticksbqwd = HAL_GetTick();
			  BQ25798_WD_RST();
		  }

		  // wyswietlenie pomiarow
	      if(sensors_data_ready) {						// taks sensorow zakonczyl dzialanie ?
	    	  sensors_data_ready = 0;
	    	  if(disp_type > 0) {
	    		  display_values(disp_type);
	    	  }
	      }

		  // zadania wykonywane co sekunde
		  if(HAL_GetTick() - secdiv >= 1000UL) {
			  secdiv = HAL_GetTick();
			  seconds++;								// zwieksz globalny licznik sekund

			  // ===================================================================================

			  // uruchomienie pomiaru
			  if(seconds - meas_start >= tim_interval || firstrun) {	// czas uruchomic pomiar ?
				  meas_start = seconds;
				  firstrun = 0;
				  if (meas_count > 0 || meas_cont_mode) {
					  if(meas_cont_mode == 0) {
						  meas_count--;
						  if(meas_count == 0) printf("Last measure\r\n");
					  }
					  vTaskResume(measTaskHandle);						// odblokuj taks pomiarow
				  }
			  }

			  // ===================================================================================

			  // czas na odczyt GPS ?, nie odczytuj w trakcie połączenia z serwerem, bo komendy bruzdza
			  if(seconds - gps_start >= gps_interval) {
				  if(Sim80x.GPRS.Connection != GPRSConnection_ConnectOK && StartReadGps()) {	// najpierw test na GPRS
					  gps_start = seconds;
					  gps_interval = 15*60;						// co 15 minut proba odczytu GPS
				  } else gps_interval += 30;					// za 30sek kolejna proba
			  }
			  // jak zlapano FIX to następny odczyt GPS za 12 godzin
			  if(Sim80x.GPS.Fix && gps_interval < 12*60*60)  gps_interval = 12*60*60;	// GPS OK, nastepny raz za 12 godzin

			  // ===================================================================================
		  }
	      __WFI();
	  }
}

