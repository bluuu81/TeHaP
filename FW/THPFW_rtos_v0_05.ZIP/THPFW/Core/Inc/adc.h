/*
 * adc.h
 *
 *  Created on: May 25, 2023
 *      Author: bluuu
 */

#ifndef INC_ADC_H_
#define INC_ADC_H_

void ADC_Print();
void ADC_DMA_Start();
float GET_MCU_Temp();

#endif /* INC_ADC_H_ */
